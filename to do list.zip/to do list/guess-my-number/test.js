const message = document.querySelector(".message");
const guessInput = document.querySelector(".guess");
const checkButton = document.querySelector(".check");
const scorePoints = document.querySelector(".score");
const highScorePoints = document.querySelector(".highscore");
const body = document.querySelector("body"); // no .body because its not a class or id that can be selected using . or #
const number = document.querySelector(".number");
const resetButton = document.querySelector(".again");

let secretNumber = Math.floor(Math.random() * 20 + 1);
let score = 20;
let highScore = 0;

console.log("secret number:" + secretNumber);

checkButton.addEventListener("click", () => {
  const guess = Number(guessInput.value);
  console.log(guess);

  if (!guess) {
    message.innerHTML = "No number typed";
  } else if (guess == secretNumber) {
    message.innerHTML = "Correct!";

    //if score is greate than highscore then change highscore to score
    if (score > highScore) {
      highScore = score;
      highScorePoints.innerHTML = highScore;
    }
    number.innerHTML = secretNumber;
    body.style.backgroundColor = "green";
  } else if (guess < secretNumber) {
    message.innerHTML = "Too Low";
    score--;
    scorePoints.innerHTML = score;
  } else if (guess > secretNumber) {
    message.innerHTML = "Too High";
    score--;
    scorePoints.innerHTML = score;
  }
});

//my answer
resetButton.addEventListener("click", () => {
  let secretNumber = Math.floor(Math.random() * 20 + 1);
  console.log("newSecret number:" + secretNumber);
  body.style.backgroundColor = "black";
  message.innerHTML = "Start Guessing...";
  score = 20;
  scorePoints.innerHTML = score;
  number.innerHTML = "?";
  guessInput.innerHTML = "?";
});

//mr edison answer
resetButton.addEventListener("click", () => {
  let secretNumber = Math.floor(Math.random() * 20 + 1);
  score = 20;
  scorePoints.innerHTML = score;
  message.innerHTML = "Start Guessing ...";
  body.style.backgroundColor = "black";
  number.innerHTML = "?";
  guessInput.value = "?";
});
